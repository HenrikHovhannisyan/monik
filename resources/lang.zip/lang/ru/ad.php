<?php

return [
    'new_season_trends' => 'Новые тренды сезона!',
    'best_summer_collection' => 'Лучшая летняя коллекция',
    'sale_get_up_to_50_off' => 'Распродажа – скидки до 50%',
    'sale_30_off' => 'Распродажа 30%',
    'shop_now' => 'Перейти в магазин',
    'new_collection' => 'Новая Коллекция',
];
