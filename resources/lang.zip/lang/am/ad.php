<?php

return [
    'new_season_trends' => 'Սեզոնի նոր թրենդները!',
    'best_summer_collection' => 'Լավագույն ամառային հավաքածու',
    'sale_get_up_to_50_off' => 'Վաճառք – զեղչեր մինչև 50%',
    'sale_30_off' => 'Զեղչ 30%',
    'shop_now' => 'Գնեք հիմա',
    'new_collection' => 'Նոր Կոլեկցիա',
];
