<?php

return [
    'invalid_credentials' => 'Էլ-փոստի հասցեն և գաղտնաբառը սխալ են:',
    'all_rights_reserved' => 'Բոլոր իրավունքները պաշտպանված են',
    'comfort_and_style' => 'Հարմարավետություն և ոճ ձեր երեխայի համար',
    'address_added' => 'Հասցեն հաջողությամբ ավելացվեց:',
    'address_updated' => 'Հասցեն հաջողությամբ թարմացվեց:',
    'address_deleted' => 'Հասցեն հաջողությամբ ջնջվեց:',
    'data_successfully_updated' => 'Տվյալները հաջողությամբ թարմվեցին։',

];
