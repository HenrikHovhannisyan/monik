<?php

return [
    'new_season_trends' => 'New Season Trends!',
    'best_summer_collection' => 'Best Summer Collection',
    'sale_get_up_to_50_off' => 'Sale - Get up to 50% Off',
    'sale_30_off' => 'Sale 30% Off',
    'shop_now' => 'Shop Now',
    'new_collection' => 'New Collection',
];
